package icha;

public class Icha {

public static void main(String[] args) {
 
    }
    
}
