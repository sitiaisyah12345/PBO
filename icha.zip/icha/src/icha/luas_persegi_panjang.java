package icha;

public class luas_persegi_panjang {
    
    public static void main(String[] args) {
        int p = 20;
        int l = 30;
        int t = 40;
        double Luas = p * l * t ;
    
    System.out.println("panjang = " + (p));
    System.out.println("panjang = " + (l));
    System.out.println("panjang = " + (t));
    System.out.println("Luas Persegi panjang = " + (Luas));
    }
}
